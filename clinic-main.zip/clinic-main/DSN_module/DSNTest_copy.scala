import chisel3._
import chisel3.iotesters._
import chisel3.util._
import org.scalatest.{Matchers, FlatSpec}

//package DSN

class DSNTest(dut: DSN) extends
	PeekPokeTester(dut) {
	
	poke(dut.io.vleak_in, dut.io.vleak_out) //feedback v_leak outside module, initial value of vleak_out = 0
	
	//-------------spike > vth condition---------------------//
	poke(dut.io.vth, "b0000010000000".U) // set vth to 128
	poke(dut.io.vpre, "b001111111".U) // set first cycle vpre to 127, wl is set to 0 aka leak, 127 + 0
	step(1) // may need more cycles to excecute
	println("spike output is: " + peek(dut.io.spike).toString) // should be 0
	poke(dut.io.vpre, "b100000010".U) // set second cycle vpre to 2, wl is set to 1 aka weight vth vs vsumout, 2 + 127
	step(1)
	println("spike output is: " + peek(dut.io.spike).toString) // should be 1
	step(3) // idk buffer it by 3 cycles why not
	
	//-------------spike < vth condition---------------------//
	poke(dut.io.vth, "b0000010000000".U) // set vth to 128
	poke(dut.io.vpre, "b001111110".U) // set first cycle vpre to 126, wl is set to 0 aka leak, 126 + 0
	step(1) // may need more cycles to excecute
	println("spike output is: " + peek(dut.io.spike).toString) // should be 0
	poke(dut.io.vpre, "b100000001".U) // set second cycle vpre to 1, wl is set to 1 aka weight vth vs vsumout, 1 + 126
	step(1)
	println("spike output is: " + peek(dut.io.spike).toString) // should be 0
	
	//-------------spike = vth condition---------------------//
	poke(dut.io.vth, "b0000010000000".U) // set vth to 128
	poke(dut.io.vpre, "b001111111".U) // set first cycle vpre to 127, wl is set to 0 aka leak, 127 + 0
	step(1) // may need more cycles to excecute
	println("spike output is: " + peek(dut.io.spike).toString) // should be 0
	poke(dut.io.vpre, "b100000001".U) // set second cycle vpre to 1, wl is set to 1 aka weight vth vs vsumout, 1 + 127
	step(1)
	println("spike output is: " + peek(dut.io.spike).toString) // should be 1
	
	}
	
	object DSN extends App {
	   chisel3.iotesters.Driver(() => new DSN()) { dut =>
	      new DSNTest(dut)
	   }
	}
